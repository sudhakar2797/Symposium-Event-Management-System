<?php if (session_status() == PHP_SESSION_NONE) {
    session_start();
} ?>

<!DOCTYPE html>
<html>
    <head>

        <link rel="shortcut icon" href="../../docs-assets/ico/favicon.png">

        <title>IT Events</title>

        <link href="assets/css/bootstrap.css" rel="stylesheet">


        <link href="assets/css/main.css" rel="stylesheet">

        <script src="assets/js/code.jquery.com_jquery-1.10.2.min.js"></script>
        <script src="assets/js/hover.zoom.js"></script>
        <script src="assets/js/hover.zoom.conf.js"></script>

    </head>

    <body>

<?php include 'NavBar.php' ?>
        <div id="ww">
            <div class="container">
                <div class="row">
                    <div class="col-lg-8 col-lg-offset-2 centered">
                        <img src="assets/img/logo.png" width="250px" height="200px" alt="IT SIMPOSIUM">
                    </div><!-- /col-lg-8 -->
                </div><!-- /row -->
            </div> <!-- /container -->
        </div><!-- /ww -->
    <center><div id="grey" style="width: 60%;word-break: break-all">
            <div class="container" align="left" style="margin-left: -180px;">
                <div class="row">
                    <div class="col-lg-8 col-lg-offset-2">
                        <p><img src="assets/img/pic.jpg" width="100px" height="100px"> <ba>Pictionary</ba></p>
                        <p>							
                            Decide who will draw for each team.<br>
                            Flip the timer over and begin drawing.<br>
                            Rotate who draws each time you need to pick a word card. <br>
                            Include all teams for “All Play” squares and cards.<br>
                            Continue to play Pictionary until a team reaches the final "All Play" square.</p>				</div>
                    <div class="col-lg-8 col-lg-offset-2">
                        <p><img src="assets/img/quiz.jpeg" width="100px" height="100px"> <ba>Quiz</ba></p>

                        <p>Only team entries are eligible.<br>
                            A team shall consist of max two persons.<br>
                            The decision of the quiz-master will be final and will not be subjected to any change.<br>
                            The participants shall not be allowed to use mobile or other electronic instruments.</p>				</div>
                    <div class="col-lg-8 col-lg-offset-2">
                        <p><img src="assets/img/paper.jpg" width="100px" height="100px"> <ba>Paper Presentation</ba></p>
                        <p>							
                            Maximum of two authors.<br>
                            Submission of abstract for not more than 300 words before the due date.<br>
                            Based on the peering review of the abstract,few papers willbe selected for presenting thepaper.<br>
                            The presentation should last a maximum of 7 minutes.		</p>		</div>
                    <div class="col-lg-8 col-lg-offset-2">
                        <p><img src="assets/img/debug.png" width="100px" height="100px"> <ba>Code Cracking</ba></p>

                        <p>Depends On situation</p>				</div>
                    <div class="col-lg-8 col-lg-offset-2">
                        <p><img src="assets/img/web.png" width="100px" height="100px"> <ba>Web Design</ba></p>

                        <p>Depends On situation</p>				</div>


                </div><!-- /row -->
            </div> <!-- /container -->
        </div></center><!-- /grey -->




    <!-- +++++ Footer Section +++++ -->
<?php include 'Footer.php' ?>
    <script src="assets/js/bootstrap.min.js"></script>
</body>
</html>
