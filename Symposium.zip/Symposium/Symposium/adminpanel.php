
<?php if (session_status() == PHP_SESSION_NONE) {
    session_start();
} ?>

<?php
$msg = "";
if (isset($_POST['go'])) {
    require 'dbconnect.php';
    $name = $_POST['name'];
    $college = $_POST['college'];
    $round = $_POST['round'];
    $event = $_POST['eventname'];
    $place = $_POST['place'];

    $stmt = $conn->prepare("INSERT INTO winner VALUES (?,?,?,?,?)");
    $stmt->bind_param("sssss", $name, $college, $event, $round, $place);
    if (($stmt->execute())) {
        $msg = "Successfully Inserted";
    } else {
        $msg = "Please Try Again";
    }
}
?>

<!DOCTYPE html>
<html>
    <head>

        <link rel="shortcut icon" href="../../docs-assets/ico/favicon.png">

        <title>IT Events</title>

        <link href="assets/css/bootstrap.css" rel="stylesheet">
        <style>.car1{
                box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.06);
                width:200px;
                height: 210px;
                word-break: break-all;
                background-color: #fff;
            }.car1:hover{
                box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.12);


            }</style>

        <link href="assets/css/main.css" rel="stylesheet">

        <script src="assets/js/code.jquery.com_jquery-1.10.2.min.js"></script>
        <script src="assets/js/hover.zoom.js"></script>
        <script src="assets/js/hover.zoom.conf.js"></script>

    </head>

    <body>

        <div class="navbar navbar-inverse navbar-static-top">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="index.html">INFORMATION TECHNOLOGY</a>
                </div>
                <div class="navbar-collapse collapse">
                    <ul class="nav navbar-nav navbar-right">
                        <li><a href="home.php">Home</a></li>

                        <li><a href="rules.php">Rules</a></li>
                        <li><a href="contact.php">Contact Us</a></li>
                        <li><a href="logout.php">Logout</a></li>
<?php if ($_SESSION['log'] == "admin") { ?>
                            <li><a href="adminpanel.php">Admin</a></li><?php } ?>

                    </ul>
                </div><!--/.nav-collapse -->
            </div>
        </div>
        <div id="ww">
            <div class="container">
                <div class="row">
                    <div class="col-lg-8 col-lg-offset-2 centered">
                        <img src="assets/img/logo.png" width="250px" height="200px" alt="IT SIMPOSIUM">
                    </div><!-- /col-lg-8 -->
                </div><!-- /row -->
            </div> <!-- /container -->
        </div><!-- /ww -->
        <link rel="stylesheet" href="assets/css/style2.css" type="text/css" media="all" />

<?php if (!empty($msg)) { ?>
            <link href="assets/css/alert.css" rel="stylesheet">
        <center>  <div class="alert info" >
                <div class="closebtn">&times;</div>  
    <?php echo $msg; ?>
            </div></center><?php } ?>
    <script>
        var close = document.getElementsByClassName("closebtn");
        var i;

        for (i = 0; i < close.length; i++) {
            close[i].onclick = function () {
                var div = this.parentElement;
                div.style.opacity = "0";
                setTimeout(function () {
                    div.style.display = "none";
                }, 600);
            }
        }
    </script>
    <center>  <br>        
        <a href="adduser.php"><div class="car1">
                <br><img src="assets/img/add-user.png" width="100px" height="100px"><h1 style="font-family:calibri"> Add User</h1></div></a>
    </center>
    <br><br><br><br>
    <div class="contain">
        <div class="card"></div>
        <div class="card"><center><h1 class="title">Event Details</h1>
                <form action="adminpanel.php" method="post">
                    <div class="input-contain">
                        <input type="text" id="#{label}" name="name" required />
                        <label for="#{label}"> Winner Name</label>
                        <div class="bar"></div>
                    </div>
                    <div class="input-contain">
                        <input type="text"  class="date-picker"  name="college" required/>
                        <label for="#{label}">College</label>
                        <div class="bar"></div>
                    </div>


                    <select name="eventname" class="login-input" required>
                        <option  value="">Event Name</option>
                        <option  value="Pictionary" >Pictionary</option>
                        <option  value="Quiz">Quiz</option>
                        <option  value="Paper Presentation" >Paper Presentation</option>
                        <option  value="Code Cracking" >Code Cracking</option>
                        <option  value="Web Design">Web Design </option>
                    </select>

                    <br>
                    <select name="round" class="login-input" required>
                        <option  value="">Round</option>
                        <option  value="1" > First</option>
                        <option  value="2">Second</option>
                        <option  value="3" >Third</option>
                    </select>

                    <br>
                    <select name="place" class="login-input" required>
                        <option  value="">Place</option>
                        <option  value="1" > First</option>
                        <option  value="2">Second</option>
                        <option  value="3" >Third</option>
                    </select>


                    <br>

                    <div class="button-contain" >
                        <button name="go" style="background-color:#357ae8" ><span>Go</span></button>
                    </div>


                </form>
        </div>
    </div>
<?php include 'Footer.php' ?>
    <script src="assets/js/bootstrap.min.js"></script>
</body>
</html>

