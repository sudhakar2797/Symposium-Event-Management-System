
<?php if (PHP_SESSION_NONE) {
    session_start();
} ?>
<?php //Connect to your database
include("dbconnect.php");
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <link rel="shortcut icon" href="../../docs-assets/ico/favicon.png">

        <title>IT Events</title>

        <!-- Bootstrap core CSS -->
        <link href="assets/css/bootstrap.css" rel="stylesheet">


        <!-- Custom styles for this template -->
        <link href="assets/css/main.css" rel="stylesheet">
        <link href="assets/css/Expand.css" rel="stylesheet">

        <script src="assets/js/code.jquery.com_jquery-1.10.2.min.js"></script>
        <script src="assets/js/hover.zoom.js"></script>
        <script src="assets/js/hover.zoom.conf.js"></script>

    </head>

    <body>
<?php include 'NavBar.php' ?>

        <div id="ww">
            <div class="container">
                <div class="row">
                    <div class="col-lg-8 col-lg-offset-2 centered">
                        <img src="assets/img/logo.png" width="250px" height="200px" alt="IT SIMPOSIUM">
                        <br><img src="assets/img/web.png" width="200px" height="200px" alt="Stanley">
                        <h1>Web Design</h1>

                    </div><!-- /col-lg-8 -->
                </div><!-- /row -->
            </div> <!-- /container -->
        </div><!-- /ww -->


    <center>     
        <div class="card"><br>
            <button class="accordion">Round</button>
            <div class="panel">
                <?php
                $query = "select * from winner where  event='Web Design' and round='1'";
                $sql = $conn->query($query);
                if ($sql->num_rows) {
                    while ($row = $sql->fetch_assoc()) {
                        $name = $row['name'];
                        $college = $row['college'];
                        $place = $row['place'];
                        ?>
                        <div class="car1"><br>
                            <h3 style="color:#398439;font-family: calibri;float: left;margin-left: 10px;">Name<b style="color:#000;"><?php echo " :  " . $name; ?></b></h3>
                            <h3 style="color:#398439;font-family: calibri;float: left;margin-left: 10px;">College<b style="color:#000;"><?php echo " :  " . $college; ?></b></h3>
                            <h3 style="color:#398439;font-family: calibri;float: left;margin-left: 10px;">Place<b style="color:#000;"><?php echo " :  " . $place; ?></b></h3>
                        </div> <br><br>            
    <?php }
} ?>
            </div>



            <script>
                var acc = document.getElementsByClassName("accordion");
                var i;
                for (i = 0; i < acc.length; i++) {
                    acc[i].onclick = function () {
                        this.classList.toggle("active");
                        this.nextElementSibling.classList.toggle("show");
                    }
                }
            </script> 
        </div>
    </center>

    <?php include 'Footer.php' ?>

    <script src="assets/js/bootstrap.min.js"></script>
</body>
</html>
