<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
?>
<?php
$msg = "";
if (isset($_POST['add'])) {
    require 'dbconnect.php';
    $name = $_POST['name'];

    $password = $_POST['password'];

    $stmt = $conn->prepare("INSERT INTO login VALUES (?,?)");
    $stmt->bind_param("ss", $name, $password);
    if (($stmt->execute())) {
        $msg = "Successfully Added";
    } else {
        $msg = "Please Try Again";
    }
}
?>

<!DOCTYPE html>
<html>
    <head>

        <link rel="shortcut icon" href="../../docs-assets/ico/favicon.png">

        <title>IT Events</title>

        <link href="assets/css/bootstrap.css" rel="stylesheet">


        <link href="assets/css/main.css" rel="stylesheet">

        <script src="assets/js/code.jquery.com_jquery-1.10.2.min.js"></script>
        <script src="assets/js/hover.zoom.js"></script>
        <script src="assets/js/hover.zoom.conf.js"></script>

    </head>

    <body>

        <div class="navbar navbar-inverse navbar-static-top">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="index.html">INFORMATION TECHNOLOGY</a>
                </div>
                <div class="navbar-collapse collapse">
                    <ul class="nav navbar-nav navbar-right">
                        <li><a href="home.php">Home</a></li>

                        <li><a href="rules.php">Rules</a></li>
                        <li><a href="contact.php">Contact Us</a></li>
                        <li><a href="logout.php">Logout</a></li>
<?php if ($_SESSION['log'] == "admin") { ?>
                            <li><a href="adminpanel.php">Admin</a></li><?php } ?>

                    </ul>
                </div><!--/.nav-collapse -->
            </div>
        </div>
        <div id="ww">
            <div class="container">
                <div class="row">
                    <div class="col-lg-8 col-lg-offset-2 centered">
                        <img src="assets/img/logo.png" width="250px" height="200px" alt="IT SIMPOSIUM">
                    </div><!-- /col-lg-8 -->
                </div><!-- /row -->
            </div> <!-- /container -->
        </div><!-- /ww -->


        <!-- +++++ Contact Section +++++ -->

<?php if (!empty($msg)) { ?>
            <link href="assets/css/alert.css" rel="stylesheet">
        <center>  <div class="alert info" >
                <div class="closebtn">&times;</div>  
    <?php echo $msg; ?>
            </div></center><?php } ?>
    <script>
        var close = document.getElementsByClassName("closebtn");
        var i;

        for (i = 0; i < close.length; i++) {
            close[i].onclick = function () {
                var div = this.parentElement;
                div.style.opacity = "0";
                setTimeout(function () {
                    div.style.display = "none";
                }, 600);
            }
        }
    </script>
    <div class="container pt">
        <div class="row mt">
            <div class="col-lg-6 col-lg-offset-3 centered">
                <h3 style="font-family:calibri">Add User</h3>
                <hr>

                <div class="card"><link rel="stylesheet" href="assets/css/login.css">
                    <div class="module form-module">
                        <div class="toggle"><i class="fa fa-times fa-pencil"></i>
                        </div>
                        <div class="form">
                            <h2>Register  New User</h2>
                            <form action="adduser.php" method="post">
                                <input type="text" placeholder="Username" name="name" required/>
                                <input type="password" placeholder="Password" name="password" required/>
                                <button name="add">Add</button>
                            </form>
                        </div></div></div>
            </div>
        </div>

    </div>
    <!-- +++++ Footer Section +++++ -->
<?php include 'Footer.php' ?>
    <script src="assets/js/bootstrap.min.js"></script>
</body>
</html>
