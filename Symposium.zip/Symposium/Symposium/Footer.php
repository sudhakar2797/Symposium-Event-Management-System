
<div id="footer">
    <div class="container">
        <div class="row">
            <div class="col-lg-4">
                <h4>KCET</h4>
                <p>
                    S.P.G.Chidambara Nadar - C.Nagammal Campus,<br/>
                    Post Box No.12  <br/>
                    Virudhunagar -626 001
                </p>
            </div><!-- /col-lg-4 -->
            <div class="col-lg-4">
                <h4>Contact</h4>
                <p>
                    Web-site: <a href="www.kamarajengg.edu.in" style="color: crimson">www.kamarajengg.edu.in</a> <br> 
                    Phone:04549 278171<br> 
                </p>
            </div><!-- /col-lg-4 -->
            <div class="col-lg-4">
                <h4>Happy Events</h4>
                <p>
                    <img src="assets/img/clients.png" width="200px" height="200px" >
                </p>
            </div><!-- /col-lg-4 -->
        </div>
    </div>
</div>