<?php

if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
if (isset($_POST['login'])) {
    if ((!empty($_POST['name'])) && (!empty($_POST['password']))) {
        include("dbconnect.php");
        $name = $_POST['name'];
        $_SESSION['log'] = $name;
        $password = $_POST['password'];
        $sql = "SELECT * FROM login where name='$name' and password='$password'";
        $result = $conn->query($sql);
        if ($result->num_rows > 0) {

            if ($role == "admin") {
                header("location:adminpanel.php");
            } else {
                header("location:home.php");
            }
        } else {

            $_SESSION['msg'] = " Enter Valid Username & Password";
            header("location:login.php");
        }
    } else {

        $_SESSION['msg'] = " Enter Valid Username & Password";
        header("location:login.php");
    }
}
?>

