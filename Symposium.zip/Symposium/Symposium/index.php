<?php if (session_status() == PHP_SESSION_NONE) {
    session_start();
} ?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <link rel="shortcut icon" href="../../docs-assets/ico/favicon.png">

        <title>IT Events</title>

        <!-- Bootstrap core CSS -->
        <link href="assets/css/bootstrap.css" rel="stylesheet">


        <!-- Custom styles for this template -->
        <link href="assets/css/main.css" rel="stylesheet">

        <script src="assets/js/code.jquery.com_jquery-1.10.2.min.js"></script>
        <script src="assets/js/hover.zoom.js"></script>
        <script src="assets/js/hover.zoom.conf.js"></script>

    </head>

    <body>

        <div class="navbar navbar-inverse navbar-static-top">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="index.html">INFORMATION TECHNOLOGY</a>
                </div>
                <div class="navbar-collapse collapse">
                    <ul class="nav navbar-nav navbar-right">
                        <li ><a href="index.php">Home</a></li>
                        <li id='myBtn'><a href="#">Rules</a></li>
                        <li id='myBtn1'><a href="#">Contact Us</a></li>
                        <li><a href="login.php">Login</a></li>

                    </ul>
                </div>
            </div>
        </div>

        <div id="ww">
            <div class="container">
                <div class="row">
                    <div class="col-lg-8 col-lg-offset-2 centered">
                        <img src="assets/img/logo.png" width="250px" height="200px" alt="IT SIMPOSIUM">
                    </div><!-- /col-lg-8 -->
                </div><!-- /row -->
            </div> <!-- /container -->
        </div><!-- /ww -->


        <!-- +++++ Projects Section +++++ -->

        <div class="container pt">
            <div class="row mt centered">	
                <div class="col-lg-4">
                    <a  id="myBtn2"><img  src="assets/img/pic.jpg" width="200px" height="200px" alt="" /></a>
                    <p>PICTIONARY</p>
                </div>
                <div class="col-lg-4">
                    <a  id="myBtn3"><img  src="assets/img/quiz.jpeg" width="200px" height="200px"  alt="" /></a>
                    <p>QUIZ</p>
                </div>
                <div class="col-lg-4">
                    <a  id="myBtn4"><img  src="assets/img/paper.jpg" width="200px" height="200px"  alt="" /></a>
                    <p>PAPER PRESENTATION</p>
                </div>
            </div><!-- /row -->
            <div class="row mt centered">	
                <div class="col-lg-4">
                    <a  id="myBtn5"><img  src="assets/img/debug.png" width="200px" height="200px"  alt="" /></a>
                    <p>CODE CRACKING</p>
                </div>
                <div class="col-lg-4">
                    <a  id="myBtn6"><img  src="assets/img/web.png" width="200px" height="200px"  alt="" /></a>
                    <p>WEB DESIGN</p>
                </div>
                <div class="col-lg-4">
                    <a  id="myBtn7"><img  src="assets/img/podium.jpg" width="200px" height="200px"  alt="" /></a>
                    <p>WINNERS / RUNNERS</p>
                </div>
            </div><!-- /row -->
        </div><!-- /container -->

     <?php include 'Footer.php' ?>
        <script src="assets/js/bootstrap.min.js"></script>
        <style>/* The Modal (background) */

            .but {
                border-radius: 4px;
                background-color: #357ae8;
                border: none;
                color: #FFFFFF;
                text-align: center;
                font-size: 16px;
                padding: 10px;
                width: 190px;
                transition: all 0.5s;
                cursor: pointer;
                margin: 5px;
            }

            .but span {
                cursor: pointer;
                display: inline-block;
                position: relative;
                transition: 0.5s;
            }

            .but span:after {
                content: ' To Login';
                position: absolute;
                opacity: 0;
                top: 0;
                right: -20px;
                transition: 0.5s;
            }

            .but:hover span {
                padding-right: 60px;
            }

            .but:hover span:after {
                opacity: 1;
                right: 0;
            }


            .modal {
                display: none; /* Hidden by default */
                position: fixed; /* Stay in place */
                padding-top: 100px; /* Location of the box */
                left: 0;
                top: 0;
                width: 100%; /* Full width */
                height: 100%; /* Full height */
                overflow: auto; /* Enable scroll if needed */
                background-color: rgb(0,0,0); /* Fallback color */
                background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
            }

            /* Modal Content */
            .modal-content {

                position: relative;
                background-color: #fefefe;
                margin: auto;
                padding: 0;
                border: 1px solid #888;
                width: 40%;
                box-shadow: 0 4px 8px 0 rgba(0,0,0,0.2),0 6px 20px 0 rgba(0,0,0,0.19);
                -webkit-animation-name: animatetop;
                -webkit-animation-duration: 0.4s;
                animation-name: animatetop;
                animation-duration: 0.4s
            }

            /* Add Animation */
            @-webkit-keyframes animatetop {
                from {top:-300px; opacity:0} 
                to {top:0; opacity:1}
            }

            @keyframes animatetop {
                from {top:-300px; opacity:0}
                to {top:0; opacity:1}
            }


            .modal-header {
                padding: 2px 16px;
                background-color: #357ae8;
                color: white;
                text-transform: capitalize;
            }

            .modal-body {padding: 2px 16px;}

            .modal-footer {
                padding: 2px 16px;
                background-color: #357ae8;
                color: white;
            }</style>

        <div id="myModal" class="modal">
            <div class="modal-content">
                <center><div class="modal-header" >
                        <h2 style="color:white;font-size: 30px;font-family: calibri;">NICTITATE'17</h2>
                    </div></center>
                <div class="modal-body" align="center"><br>
                    <img src="assets/img/login.jpg"width=200px" height="200px" >
                    <h5 style="color:black;font-family: calibri;font-size: 25px;style:bold;"> Please <b style="display:inline; color:crimson;">Login</b> First.....
                        <a href="login.php"><button class="but"><span>Click Here</span></button></a></h5>
                </div>
                <div class="modal-footer" alifn="center">
                    <center><h3 style="color:white">!!!.....Welcome To All.....!!!</h3></center>
                </div>
            </div>
        </div>
        <script>
   // Get the modal
            var modal = document.getElementById('myModal');

   // Get the button that opens the modal
            var btn = document.getElementById("myBtn");
            var btn1 = document.getElementById("myBtn1");
            var btn2 = document.getElementById("myBtn2");
            var btn3 = document.getElementById("myBtn3");
            var btn4 = document.getElementById("myBtn4");
            var btn5 = document.getElementById("myBtn5");
            var btn6 = document.getElementById("myBtn6");
            var btn7 = document.getElementById("myBtn7");

   // Get the <span> element that closes the modal

   // When the user clicks the button, open the modal 
            btn.onclick = function () {
                modal.style.display = "block";
            }

   // When the user clicks the button, open the modal 
            btn1.onclick = function () {
                modal.style.display = "block";
            }

   // When the user clicks the button, open the modal 
            btn2.onclick = function () {
                modal.style.display = "block";
            }

   // When the user clicks the button, open the modal 
            btn3.onclick = function () {
                modal.style.display = "block";
            }


   // When the user clicks the button, open the modal 
            btn4.onclick = function () {
                modal.style.display = "block";
            }


   // When the user clicks the button, open the modal 
            btn5.onclick = function () {
                modal.style.display = "block";
            }


   // When the user clicks the button, open the modal 
            btn6.onclick = function () {
                modal.style.display = "block";
            }

   // When the user clicks the button, open the modal 
            btn7.onclick = function () {
                modal.style.display = "block";
            }


        </script>

    </body>
</html>
