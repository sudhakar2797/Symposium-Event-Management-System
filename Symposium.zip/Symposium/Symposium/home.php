<?php if (session_status() == PHP_SESSION_NONE) {
    session_start();
} ?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <link rel="shortcut icon" href="../../docs-assets/ico/favicon.png">

        <title>IT Events</title>

        <!-- Bootstrap core CSS -->
        <link href="assets/css/bootstrap.css" rel="stylesheet">


        <!-- Custom styles for this template -->
        <link href="assets/css/main.css" rel="stylesheet">

        <script src="assets/js/code.jquery.com_jquery-1.10.2.min.js"></script>
        <script src="assets/js/hover.zoom.js"></script>
        <script src="assets/js/hover.zoom.conf.js"></script>

    </head>

    <body>
<?php include 'NavBar.php' ?>

        <div id="ww">
            <div class="container">
                <div class="row">
                    <div class="col-lg-8 col-lg-offset-2 centered">
                        <img src="assets/img/logo.png" width="250px" height="200px" alt="IT SIMPOSIUM">
                    </div><!-- /col-lg-8 -->
                </div><!-- /row -->
            </div> <!-- /container -->
        </div><!-- /ww -->


        <!-- +++++ Projects Section +++++ -->

        <div class="container pt">
            <div class="row mt centered">	
                <div class="col-lg-4">
                    <a  href="pictionary.php"><img  src="assets/img/pic.jpg" width="200px" height="200px" alt="" /></a>
                    <p>PICTIONARY</p>
                </div>
                <div class="col-lg-4">
                    <a  href="quiz.php"><img  src="assets/img/quiz.jpeg" width="200px" height="200px"  alt="" /></a>
                    <p>QUIZ</p>
                </div>
                <div class="col-lg-4">
                    <a  href="paperpresentation.php"><img  src="assets/img/paper.jpg" width="200px" height="200px"  alt="" /></a>
                    <p>PAPER PRESENTATION</p>
                </div>
            </div><!-- /row -->
            <div class="row mt centered">	
                <div class="col-lg-4">
                    <a  href="codecracking.php"><img  src="assets/img/debug.png" width="200px" height="200px"  alt="" /></a>
                    <p>CODE CRACKING</p>
                </div>
                <div class="col-lg-4">
                    <a  href="webdesign.php"><img  src="assets/img/web.png" width="200px" height="200px"  alt="" /></a>
                    <p>WEB DESIGN</p>
                </div>
                <div class="col-lg-4">
                    <a  href="user.php"><img  src="assets/img/podium.jpg" width="200px" height="200px"  alt="" /></a>
                    <p>WINNERS / RUNNERS</p>
                </div>
            </div><!-- /row -->
        </div><!-- /container -->
<?php include 'Footer.php' ?>
        <script src="assets/js/bootstrap.min.js"></script>
    </body>
</html>
