<div class="navbar navbar-inverse navbar-static-top">
    <div class="container">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a class="navbar-brand" href="index.html">INFORMATION TECHNOLOGY</a>
        </div>
        <div class="navbar-collapse collapse">
            <ul class="nav navbar-nav navbar-right">
                <li><a href="home.php">Home</a></li>
                <li><a href="rules.php">Rules</a></li>
                <li><a href="contact.php">Contact Us</a></li>
                <?php if ($_SESSION['log'] == "admin") { ?>
                    <li><a href="adminpanel.php">Admin</a></li><?php } ?>
                <li><a href="logout.php">Logout</a></li>
            </ul>
            </ul>
        </div>
    </div>
</div>