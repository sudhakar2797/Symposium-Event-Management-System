x      <?php if (session_status() == PHP_SESSION_NONE) {
    session_start();
} ?>

<!DOCTYPE html>
<html>
    <head>

        <link rel="shortcut icon" href="../../docs-assets/ico/favicon.png">

        <title>IT Events</title>

        <link href="assets/css/bootstrap.css" rel="stylesheet">


        <link href="assets/css/main.css" rel="stylesheet">

        <script src="assets/js/code.jquery.com_jquery-1.10.2.min.js"></script>
        <script src="assets/js/hover.zoom.js"></script>
        <script src="assets/js/hover.zoom.conf.js"></script>

    </head>

    <body>

<?php include 'NavBar.php' ?>
        <div id="ww">
            <div class="container">
                <div class="row">
                    <div class="col-lg-8 col-lg-offset-2 centered">
                        <img src="assets/img/logo.png" width="250px" height="200px" alt="IT SIMPOSIUM">
                    </div><!-- /col-lg-8 -->
                </div><!-- /row -->
            </div> <!-- /container -->
        </div><!-- /ww -->


        <!-- +++++ Contact Section +++++ -->

        <div class="container pt">
            <div class="row mt">
                <div class="col-lg-6 col-lg-offset-3 centered">
                    <h3>CONTACT US</h3>
                    <hr>
                    <p>If You Have Any Difficulty Please Contact Our Department Events Coordinator</p>
                </div>
            </div>
            <div class="row mt">	
                <div class="col-lg-8 col-lg-offset-2">
                    <form role="form" action="checkcontactus.php" method="post">
                        <div class="form-group">
                            <input type="name" class="form-control"  name="ccon" id="NameInputEmail1" placeholder="Your Name">
                            <br>
                        </div>
                        <div class="form-group">
                            <input type="email" class="form-control" name="cemail" id="exampleInputEmail1" placeholder="Enter email">
                            <br>
                        </div>

                        <textarea class="form-control" rows="6" name="query" placeholder="Enter your text here"></textarea>
                        <br>
                        <button type="submit" name="send" class="btn btn-success">SUBMIT</button>
                    </form>    			
                </div>
            </div><!-- /row -->
        </div><!-- /container -->


        <!-- +++++ Footer Section +++++ -->
<?php include 'Footer.php' ?>
        <script src="assets/js/bootstrap.min.js"></script>
    </body>
</html>
