
<?php if (PHP_SESSION_NONE) {
    session_start();
} ?>
<?php //Connect to your database
include("dbconnect.php");
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <link rel="shortcut icon" href="../../docs-assets/ico/favicon.png">

        <title>IT Events</title>

        <!-- Bootstrap core CSS -->
        <link href="assets/css/bootstrap.css" rel="stylesheet">


        <!-- Custom styles for this template -->
        <link href="assets/css/main.css" rel="stylesheet">
        <link href="assets/css/Expand.css" rel="stylesheet">
        <script src="assets/js/code.jquery.com_jquery-1.10.2.min.js"></script>
        <script src="assets/js/hover.zoom.js"></script>
        <script src="assets/js/hover.zoom.conf.js"></script>

    </head>

    <body>

<?php include 'NavBar.php' ?>

        <div id="ww">
            <div class="container">
                <div class="row">
                    <div class="col-lg-8 col-lg-offset-2 centered">
                        <img src="assets/img/logo.png" width="250px" height="200px" alt="IT SIMPOSIUM">
                        <br><img src="assets/img/th.jpeg" width="200px" height="200px" alt="Stanley">
                        <h1>Hello <?php echo $_SESSION['log']; ?></h1>

                    </div><!-- /col-lg-8 -->
                </div><!-- /row -->
            </div> <!-- /container -->
        </div><!-- /ww -->


    <center>     
        <div class="card"><br>
            <button class="accordion">Pictionary</button>
            <div class="panel">
                <?php
                $name = $_SESSION['log'];
                $query = "select * from winner where name = '$name' and event='Pictionary'";
                $sql = $conn->query($query);
                if ($sql->num_rows) {
                    while ($row = $sql->fetch_assoc()) {
                        $place = $row['place'];
                        $round = $row['round'];
                    }
                    ?>
                    <h1 style="color:#4CAF50;font-family: calibri;">Your Is A Winner & Your Place Is<?php echo"     " . $place; ?><br> In Round <?php echo $round; ?></h1>
                    <img src="assets/img/mission-512.png" width="200px" height="200px">
                <?php } else { ?>
                    <h1 style="color:crimson;font-family: calibri;">Your  Not A Winner </h1>
                    <img src="assets/img/Icon_Fail_1.png" width="250px" height="200px"> 
                <?php } ?>
            </div>
            <button class="accordion">Quiz</button>
            <div class="panel">
                <?php
                $name = $_SESSION['log'];
                $query = "select * from winner where name = '$name' and event='Quiz'";
                $sql = $conn->query($query);
                if ($sql->num_rows) {
                    while ($row = $sql->fetch_assoc()) {
                        $place = $row['place'];
                        $round = $row['round'];
                    }
                    ?>
                    <h1 style="color:#4CAF50;font-family: calibri;">Your Is A Winner & Your Place Is<?php echo"     " . $place; ?><br> In Round <?php echo $round; ?></h1>
                    <img src="assets/img/mission-512.png" width="200px" height="200px">
                <?php } else { ?>
                    <h1 style="color:crimson;font-family: calibri;">Your  Not A Winner </h1>
                    <img src="assets/img/Icon_Fail_1.png" width="250px" height="200px"> 
                <?php } ?>  </div>
            <button class="accordion">Paper Presentation</button>
            <div class="panel">
                <?php
                $name = $_SESSION['log'];
                $query = "select * from winner where name = '$name' and event='Paper Presentation'";
                $sql = $conn->query($query);
                if ($sql->num_rows) {
                    while ($row = $sql->fetch_assoc()) {
                        $place = $row['place'];
                        $round = $row['round'];
                    }
                    ?>
                    <h1 style="color:#4CAF50;font-family: calibri;">Your Is A Winner & Your Place Is<?php echo"     " . $place; ?><br> In Round <?php echo $round; ?></h1>
                    <img src="assets/img/mission-512.png" width="200px" height="200px">
                <?php } else { ?>
                    <h1 style="color:crimson;font-family: calibri;">Your  Not A Winner </h1>
                    <img src="assets/img/Icon_Fail_1.png" width="250px" height="200px"> 
                <?php } ?>   
            </div>
            <button class="accordion">Code Cracking</button>
            <div class="panel">
                <?php
                $name = $_SESSION['log'];
                $query = "select * from winner where name = '$name' and event='Code Cracking'";
                $sql = $conn->query($query);
                if ($sql->num_rows) {
                    while ($row = $sql->fetch_assoc()) {
                        $place = $row['place'];
                        $round = $row['round'];
                    }
                    ?>
                    <h1 style="color:#4CAF50;font-family: calibri;">Your Is A Winner & Your Place Is<?php echo"     " . $place; ?><br> In Round <?php echo $round; ?></h1>
                    <img src="assets/img/mission-512.png" width="200px" height="200px">
                <?php } else { ?>
                    <h1 style="color:crimson;font-family: calibri;">Your  Not A Winner </h1>
                    <img src="assets/img/Icon_Fail_1.png" width="250px" height="200px"> 
<?php } ?>  
            </div>
            <button class="accordion">Web Design</button>
            <div id="foo" class="panel">

<?php
$name = $_SESSION['log'];
$query = "select * from winner where name = '$name' and event='Web Design'";
$sql = $conn->query($query);
if ($sql->num_rows) {
    while ($row = $sql->fetch_assoc()) {
        $place = $row['place'];
        $round = $row['round'];
    }
    ?>
                    <h1 style="color:#4CAF50;font-family: calibri;">Your Is A Winner & Your Place Is<?php echo"     " . $place; ?><br> In Round <?php echo $round; ?></h1>
                    <img src="assets/img/mission-512.png" width="200px" height="200px">
<?php } else { ?>
                    <h1 style="color:crimson;font-family: calibri;">Your  Not A Winner </h1>
                    <img src="assets/img/Icon_Fail_1.png" width="250px" height="200px"> 
<?php } ?>      </div>         

            <script>
                var acc = document.getElementsByClassName("accordion");
                var i;
                for (i = 0; i < acc.length; i++) {
                    acc[i].onclick = function () {
                        this.classList.toggle("active");
                        this.nextElementSibling.classList.toggle("show");
                    }
                }
            </script> 
        </div>
    </center>

    <?php include 'Footer.php' ?>

    <script src="assets/js/bootstrap.min.js"></script>
</body>
</html>
